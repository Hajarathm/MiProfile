
public class Ca {

	public static void main(String[] args) {
		 int x = 10;
		 int y = 30;
		if (x*y<200)
		System.out.println(":::" +x*y);
	}
}
