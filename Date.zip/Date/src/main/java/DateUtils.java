import java.text.ParseException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DateUtils {
//	public static Date addDay(LocalDateTime now, int day) {
//		Calendar calendar = Calendar.getInstance();
//		calendar.add(Calendar.DATE, day);
//		return calendar.getTime();
	
	public static void main(String[] args) {
//        LocalDate dt1 = LocalDate.parse("2022-09-16");
//        LocalDate dt2= LocalDate.parse("2022-10-02");
//
//        long diffDays = ChronoUnit.DAYS.between(dt1, dt2);
//        if (diffDays == 15) {
//        	System.out.println("Inside if");
//        }
//
//        System.out.println("diffDays" +diffDays);
//	}
	}


