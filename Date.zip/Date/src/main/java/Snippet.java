

public class Snippet {
	public static void main(String[] args) {
		t24AppzRequestDTO
	}
}